const express = require('express');
const multer = require('multer');
const Tesseract = require('tesseract.js');
const { Configuration, OpenAIApi } = require('openai');
const cors = require('cors');
const fs = require('fs');
require('dotenv').config();

const app = express();
const port = 5000;

app.use(cors());
app.use(express.json());

const upload = multer({ dest: 'uploads/' });

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

app.post('/api/upload', upload.single('file'), async (req, res) => {
  const filePath = req.file.path;

  try {
    const { data: text } = await Tesseract.recognize(filePath, 'eng');
    fs.unlinkSync(filePath);

    const prompt = `Here is a user's expense snapshot:\n"""\n${text}\n"""\nGive brutally honest, creative, quirky savings advice. Be concise.`;

    const completion = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.8,
    });

    const advice = completion.data.choices[0].message.content;
    res.json({ advice });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Processing failed' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});